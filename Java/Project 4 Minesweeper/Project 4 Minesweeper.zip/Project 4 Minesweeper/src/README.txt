Ayub Mohamoud (moha1660)

To compile and run the program. Open terminal. Move to the directory containing the file. Code is compiled
and run normally. Run the class Main as it stores the main method to run the Minesweeper game.

Assumptions: 1. You will choose one of the 3 difficulties (Easy, Medium, Hard)
             2. As revealStartingArea also reveals 1 mine, that mine must be flagged
                before anything else can be flagged. Else the game ends.
             3. The console also prints out the debugged minefield so as the player knows
                what to guess

I was unable to figure out a way to properly space out the board once the dimension of the minefield
reached double digits.

No known bugs or defects.

No outside sources used.

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.
- Ayub Mohamoud