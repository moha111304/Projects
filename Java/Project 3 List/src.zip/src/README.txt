Ayub Mohamoud (moha1660)

To compile and run the program. Open terminal. Move to the directory containing the file. Code is compiled
and run normally. Though the tests should be the only thing that runs as the classes don't have a main method.

No assumption;

For the array list and additional method called private void grow() was implement which just create a new array
with double the capacity of the current array and all the same elements. For both the array and linked lists
classes a method called private boolean checkIfSorted() was implemented which checks if the list is sorted.

No known bugs or defects.

No outside sources used.

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.
- Ayub Mohamoud